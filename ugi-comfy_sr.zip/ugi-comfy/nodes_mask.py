﻿# -*- coding: utf-8 -*-
import os
import torch
import numpy as np
import requests
import io
import json
from PIL import Image, ImageDraw, ImageFont
from .config import get_local_font_list, get_style_list, STYLE_DIR
from .utils import load_font, pil2tensor, extract_prompt_from_style

FONT_API_BASE = "https://gradioapi.font.z-w.vip"
FONT_LIST_URL = f"{FONT_API_BASE}/api/listfonts"
FONT_RENDER_URL = f"{FONT_API_BASE}/api/truetype"

def fetch_api_font_list():
    try:
        resp = requests.get(FONT_LIST_URL, timeout=5)
        data = json.loads(resp.content.decode('utf-8'))
        if data.get("code") == 0:
            return data["data"]["ttf"]
    except Exception as e:
        print(f"[UGF-Comfy] 获取远程字体列表失败: {e}")
    return ["default"]

class UGF_StyleLoader:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "style_png": (get_style_list(),),
                "override_prompt": ("STRING", {"multiline": True, "default": ""}),
            }
        }
    RETURN_TYPES = ("IMAGE", "STRING")
    RETURN_NAMES = ("style_image", "style_prompt")
    FUNCTION = "load"
    CATEGORY = "UGF-Comfy/1-Mask"

    def load(self, style_png, override_prompt):
        if style_png == "None":
            return (torch.zeros((1, 512, 512, 3)), override_prompt)
        img = Image.open(os.path.join(STYLE_DIR, style_png)).convert("RGB")
        builtin_prompt = extract_prompt_from_style(style_png)
        final_prompt = override_prompt if override_prompt.strip() else builtin_prompt
        return (pil2tensor(img), final_prompt)

class UGF_FontListFetcher:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {}}
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("font_list",)
    FUNCTION = "fetch"
    CATEGORY = "UGF-Comfy/1-Mask"
    OUTPUT_IS_LIST = (True,)

    def fetch(self):
        return (fetch_api_font_list(),)

class UGF_TextMask:
    @classmethod
    def INPUT_TYPES(cls):
        remote_fonts = fetch_api_font_list()
        if not remote_fonts: 
            remote_fonts = ["default"] 
            
        return {
            "required": {
                "text": ("STRING", {"multiline": True, "default": ""}),
                "font_source": (["local", "api"], {"default": "local"}),
                "local_font": (get_local_font_list(), {"default": "msyh.ttc"}),
                "api_font": (remote_fonts, {"force_input": True, "default": remote_fonts[0]}),
                "font_size": ("INT", {"default": 256, "min": 8, "max": 1024}),
                "text_color": ("STRING", {"default": "#000000"}),
                "manual_width": ("INT", {"default": 0, "min": 0, "max": 4096}),
                "manual_height": ("INT", {"default": 0, "min": 0, "max": 4096}),
            }
        }
    RETURN_TYPES = ("MASK", "IMAGE")
    RETURN_NAMES = ("text_mask", "rgba_preview")
    FUNCTION = "generate"
    CATEGORY = "UGF-Comfy/1-Mask"

    def generate(self, text, font_source, local_font, api_font, font_size, text_color, manual_width, manual_height):
        if not text.strip():
            canvas_h = manual_height if manual_height > 0 else font_size
            canvas_w = manual_width if manual_width > 0 else font_size
            canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
            mask_t = torch.zeros((1, canvas_h, canvas_w))
            return (mask_t, pil2tensor(canvas))

        canvas_h = manual_height if manual_height > 0 else font_size
        clean_text = text.replace("\n", "").strip()
        canvas_w = manual_width if manual_width > 0 else max(1, len(clean_text)) * canvas_h
        
        # --- API 渲染 ---
        if font_source == "api" and api_font:
            params = {
                "f": api_font, 
                "t": text, 
                "s": str(font_size),
                "tc": text_color.lstrip("#"), 
                "bc": "FFFFFF", 
                "o": "file"     
            }
            try:
                resp = requests.get(FONT_RENDER_URL, params=params, timeout=15)
                if resp.status_code == 200 and "image" in resp.headers.get("Content-Type", ""):
                    api_img = Image.open(io.BytesIO(resp.content)).convert("RGBA")
                    
                    # 【关键修复】强制将白色背景转为透明，防止API返回无Alpha图导致Mask全白
                    datas = api_img.getdata()
                    new_data = []
                    for item in datas:
                        if item[0] > 240 and item[1] > 240 and item[2] > 240:
                            new_data.append((0, 0, 0, 0)) 
                        else:
                            new_data.append(item)
                    api_img.putdata(new_data)
                    
                    # 贴图
                    alpha = api_img.split()[3]
                    canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
                    paste_x = (canvas_w - api_img.width) // 2
                    paste_y = (canvas_h - api_img.height) // 2
                    canvas.paste(api_img, (paste_x, paste_y), alpha)
                    
                    final_alpha = canvas.split()[3]
                    mask_t = torch.from_numpy(np.array(final_alpha).astype(np.float32) / 255.0).unsqueeze(0)
                    return (mask_t, pil2tensor(canvas))
                else:
                    print(f"[UGF-Comfy] API 渲染失败，回退本地。状态码: {resp.status_code}")
            except Exception as e:
                print(f"[UGF-Comfy] API 请求失败: {e}")
        
        # --- 本地渲染 ---
        print(f"[UGF-Comfy] 使用本地字体渲染 (字体: {local_font})")
        canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(canvas)
        
        try:
            f = load_font(local_font, font_size)
        except Exception as e:
            f = ImageFont.load_default()

        bbox = draw.textbbox((0, 0), text, font=f)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x = (canvas_w - tw) // 2 - bbox[0]
        y = (canvas_h - th) // 2 - bbox[1]
        
        draw.text((x, y), text, font=f, fill=text_color)
        
        alpha = canvas.split()[3]
        mask_t = torch.from_numpy(np.array(alpha).astype(np.float32) / 255.0).unsqueeze(0)
        
        return (mask_t, pil2tensor(canvas))