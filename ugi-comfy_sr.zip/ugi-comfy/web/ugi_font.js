import { app } from "../../scripts/app.js";
app.registerExtension({
name: "ugi-font",
async setup() {
console.log("UGI-Font Plugin Loaded");
}
})
