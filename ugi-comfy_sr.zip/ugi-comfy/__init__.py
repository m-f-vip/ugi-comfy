﻿# __init__.py
from .nodes_mask import UGF_StyleLoader, UGF_TextMask, UGF_FontListFetcher
from .nodes_poster import UGF_PosterGenerator
from .nodes_media import UGF_VideoAudioSaver

NODE_CLASS_MAPPINGS = {
    "UGF_StyleLoader": UGF_StyleLoader,
    "UGF_TextMask": UGF_TextMask,
    "UGF_FontListFetcher": UGF_FontListFetcher,
    "UGF_PosterGenerator": UGF_PosterGenerator,
    "UGF_VideoAudioSaver": UGF_VideoAudioSaver,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "UGF_StyleLoader": "1. Style Loader",
    "UGF_TextMask": "1. Text Mask (Pure Gen)",
    "UGF_FontListFetcher": "1. Fetch API Fonts",
    "UGF_PosterGenerator": "2. Poster Inpaint",
    "UGF_VideoAudioSaver": "3. Video + Audio",
}
__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']