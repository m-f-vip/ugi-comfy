﻿import os, json
import torch
import numpy as np
from PIL import Image, ImageFont
from .config import FONT_DIR, STYLE_DIR

def load_font(font_name, size):
    if font_name == "default":
        try: return ImageFont.truetype("C:/Windows/Fonts/arial.ttf", size)
        except: return ImageFont.load_default()
    local_path = os.path.join(FONT_DIR, font_name)
    if os.path.exists(local_path): return ImageFont.truetype(local_path, size)
    win_path = f"C:/Windows/Fonts/{font_name}"
    if os.path.exists(win_path): return ImageFont.truetype(win_path, size)
    return ImageFont.load_default()

def pil2tensor(image):
    return torch.from_numpy(np.array(image).astype(np.float32) / 255.0).unsqueeze(0)

def extract_prompt_from_style(style_name):
    if style_name == "None": return ""
    base_name = os.path.splitext(style_name)[0]
    txt_path = os.path.join(STYLE_DIR, f"{base_name}.txt")
    if os.path.exists(txt_path):
        with open(txt_path, "r", encoding="utf-8") as f:
            return f.read().strip()
            
    png_path = os.path.join(STYLE_DIR, style_name)
    try:
        img = Image.open(png_path)
        if "prompt" in img.info: 
            prompt_data = json.loads(img.info["prompt"])
            for node_id, node_info in prompt_data.items():
                if node_info.get("class_type") == "CLIPTextEncode":
                    text = node_info.get("inputs", {}).get("text", "")
                    if text and "negative" not in text.lower():
                        return text.strip()
        elif "parameters" in img.info: 
            return img.info["parameters"].split("Negative prompt:")[0].strip()
    except Exception:
        pass
    return ""