﻿import torch, nodes
import comfy.samplers

class UGF_PosterGenerator:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",), "clip": ("CLIP",), "vae": ("VAE",),
                "background_image": ("IMAGE",), "text_mask": ("MASK",),
                "positive_prompt": ("STRING", {"multiline": True, "default": "commercial poster, typography"}),
                "negative_prompt": ("STRING", {"multiline": True, "default": "blurry, watermark, text"}),
                "denoise": ("FLOAT", {"default": 0.75, "min": 0.0, "max": 1.0, "step": 0.01}),
                "steps": ("INT", {"default": 28, "min": 1, "max": 150}),
                "cfg": ("FLOAT", {"default": 6.0, "min": 0.0, "max": 30.0}),
                "sampler_name": (comfy.samplers.KSampler.SAMPLERS,),
                "scheduler": (comfy.samplers.KSampler.SCHEDULERS,),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffff}),
            }
        }
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("final_poster",)
    FUNCTION = "generate"
    CATEGORY = "UGF-Comfy/2-Poster"

    def generate(self, model, clip, vae, background_image, text_mask, positive_prompt, negative_prompt, denoise, steps, cfg, sampler_name, scheduler, seed):
        pos = nodes.CLIPTextEncode().encode(clip, positive_prompt)[0]
        neg = nodes.CLIPTextEncode().encode(clip, negative_prompt)[0]
        
        B, H, W, C = background_image.shape
        if text_mask.shape[1] != H or text_mask.shape[2] != W:
            text_mask = torch.nn.functional.interpolate(text_mask.unsqueeze(1), size=(H, W), mode='bilinear').squeeze(1)
            
        latent = vae.encode(background_image)
        try:
            from comfy_extras.nodes_mask import SetLatentNoiseMask
            latent = SetLatentNoiseMask().mask(latent, text_mask)[0]
        except ImportError:
            latent["noise_mask"] = text_mask.unsqueeze(1)
            
        samples = nodes.KSampler().sample(model, seed, steps, cfg, sampler_name, scheduler, pos, neg, latent, denoise)[0]
        return (nodes.VAEDecode().decode(vae, samples)[0],)
        
        