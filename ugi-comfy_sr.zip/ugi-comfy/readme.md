
# 📘 UGI-Comfy 插件使用文档
下载后，请解压，标准zip格式
下载地址：
魔塔：https://www.modelscope.cn/models/bd25vip/ugi-comfy
github：https://github.com/m-f-vip/ugi-comfy


## 1. 简介
ugi-comfy是丑字AGI的ComfyUI插件。专为 ComfyUI 设计的广告/海报/短视频生成套件。它不需要加载任何扩散模型，就能直接通过本地 TTF 字体或远程 API 生成高精度的 32位透明通道文字 Mask，并将该 Mask 无缝接入下游的 SD/Flux 图像重绘，最后结合音频自动压制 MP4。

## 2. 目录结构
在 `ComfyUI/custom_nodes/` 下新建 `ugi-comfy`：
```text
ComfyUI/custom_nodes/ugi-comfy/
├── __init__.py
├── config.py
├── utils.py
├── nodes_mask.py      # 1# 核心文字Mask生成（本地/API/透明底/自动尺寸）
├── nodes_poster.py    # 2# 海报局部重绘
├── nodes_media.py     # 3# 视频音频合成
├── requirements.txt
├── fonts/             # 放入你的 .ttf 字体
└── doc/               # 配套资源，说明文档目录
```

ugi_mask_bas-001.json，基础文本mask生成
ugi_q_image21-010.json，基础文本mask图像+图像编辑模型
ugi_q_image21-020.json，ugi直接生成+图像编辑模型
案例图像编辑模型是：qwen image edit2.1，可自己更换。
视频模型，参考以上工作流，插入ugi相关节点即可。
更多，参考flux，qimage等图像，与视频集成工作流即可。


## 3. 节点说明
1. **模板加载器 (`UGF_StyleLoader`)**：读取 `styles/` 中的 PNG，并自动提取同名 `.txt` 或图片内置的提示词。
2. **文本 Mask (`UGF_TextMask`)**：
   - **智能尺寸**：默认 `font_size=256`，`height = font_size`，`width = 字数 * height`（可手动覆盖）。
   - **双引擎**：本地读取 TTF，或调用 API（自动处理 URL 编码、防乱码）。
   - **完美输出**：无论本地还是 API，最终都会强制抠除白底，输出透明底的 RGBA 预览图和纯白遮罩（Mask）。
3. **海报生成 (`UGF_PosterGenerator`)**：接收背景图和 Mask，调用 ComfyUI 原生 KSampler 进行局部重绘。
4. **视频音频合成 (`UGF_VideoAudioSaver`)**：接收帧序列和音频，调用 FFmpeg 压制带 AAC 音轨的 MP4。

---
