﻿import os, subprocess, time
import folder_paths
import numpy as np
import imageio

class UGF_VideoAudioSaver:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "frames": ("IMAGE",),
                "fps": ("INT", {"default": 8, "min": 1, "max": 60}),
                "filename_prefix": ("STRING", {"default": "ugf_video"}),
            },
            "optional": {
                "audio": ("AUDIO",), 
            }
        }
    RETURN_TYPES = ()
    OUTPUT_NODE = True
    FUNCTION = "save_video"
    CATEGORY = "UGF-Comfy/3-Media"

    def save_video(self, frames, fps, filename_prefix, audio=None):
        output_dir = folder_paths.get_output_directory()
        os.makedirs(os.path.join(output_dir, "ugf_output"), exist_ok=True)
        filename = f"{filename_prefix}_{int(time.time())}.mp4"
        filepath = os.path.join(output_dir, "ugf_output", filename)
        temp_video = filepath.replace(".mp4", "_temp.mp4")
        
        writer = imageio.get_writer(temp_video, fps=fps, codec="libx264", quality=8, pixelformat="yuv420p", macro_block_size=8)
        for frame in frames:
            writer.append_data((frame.cpu().numpy() * 255).astype(np.uint8))
        writer.close()

        if audio is not None:
            temp_audio = filepath.replace(".mp4", ".wav")
            import scipy.io.wavfile as wavfile
            wav_data = (audio["waveform"].squeeze().cpu().numpy() * 32767).astype(np.int16)
            wavfile.write(temp_audio, audio["sample_rate"], wav_data.T)

            ffmpeg_exe = imageio.plugins.ffmpeg.get_exe()
            cmd = [ffmpeg_exe, "-y", "-i", temp_video, "-i", temp_audio, "-c:v", "copy", "-c:a", "aac", "-shortest", filepath]
            flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            subprocess.run(cmd, check=True, creationflags=flags)
            os.remove(temp_video)
            os.remove(temp_audio)
        else:
            os.rename(temp_video, filepath)
            
        return {"ui": {"text": [filepath]}}