﻿import os

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(PLUGIN_DIR, "fonts")
STYLE_DIR = os.path.join(PLUGIN_DIR, "styles")

for d in [FONT_DIR, STYLE_DIR]:
    os.makedirs(d, exist_ok=True)

def get_local_font_list():
    """获取本地 fonts/ 目录以及 Windows 系统字体"""
    fonts = ["default"]
    if os.path.exists(FONT_DIR):
        fonts.extend([f for f in os.listdir(FONT_DIR) if f.lower().endswith(('.ttf', '.otf', '.ttc'))])
    win_fonts = ["msyh.ttc", "simhei.ttf", "simsun.ttc", "arial.ttf"]
    for wf in win_fonts:
        if os.path.exists(f"C:/Windows/Fonts/{wf}"):
            fonts.append(wf)
    return sorted(list(set(fonts)))

def get_style_list():
    """获取 styles/ 目录下的 png 模板"""
    if not os.path.exists(STYLE_DIR):
        return ["None"]
    styles = [f for f in os.listdir(STYLE_DIR) if f.lower().endswith('.png')]
    return ["None"] + sorted(styles)